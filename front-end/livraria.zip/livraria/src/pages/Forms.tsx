const forms = () => {
    return <div>Forms</div>;
};
export default forms;